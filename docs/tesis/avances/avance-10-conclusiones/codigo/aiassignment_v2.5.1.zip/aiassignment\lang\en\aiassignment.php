<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'AI Assignment';
$string['modulenameplural'] = 'AI Assignments';
$string['modulename_help'] = 'The AI Assignment module allows teachers to create assignments that are automatically evaluated using artificial intelligence.';
$string['pluginname'] = 'AI Assignment';
$string['pluginadministration'] = 'AI Assignment administration';

// Capabilities
$string['aiassignment:addinstance'] = 'Add a new AI Assignment';
$string['aiassignment:view'] = 'View AI Assignment';
$string['aiassignment:submit'] = 'Submit answer';
$string['aiassignment:grade'] = 'Grade submissions';
$string['aiassignment:viewgrades'] = 'View grades';

// Form
$string['assignmentname'] = 'Assignment name';
$string['problemsettings'] = 'Problem settings';
$string['problemtype'] = 'Problem type';
$string['problemtype_help'] = 'Select the type of problem: Mathematics or Programming';
$string['math'] = 'Mathematics';
$string['programming'] = 'Programming';
$string['solution'] = 'Reference solution';
$string['solution_help'] = 'Enter the correct solution that will be used by AI to compare student answers';
$string['documentation'] = 'Additional documentation';
$string['documentation_help'] = 'Optional additional information for students';
$string['testcases'] = 'Test cases';
$string['testcases_help'] = 'Optional test cases or examples';
$string['gradesettings'] = 'Grade settings';
$string['maxattempts'] = 'Maximum attempts';
$string['maxattempts_help'] = 'Maximum number of submission attempts allowed. 0 = unlimited';

// View
$string['problemdescription'] = 'Problem description';
$string['type'] = 'Type';
$string['submitanswer'] = 'Submit your answer';
$string['submit'] = 'Submit';
$string['attemptsremaining'] = 'Attempts remaining: {$a}';
$string['maxattemptsreached'] = 'You have reached the maximum number of attempts';
$string['yoursubmissions'] = 'Your submissions';
$string['submitted'] = 'Submitted';
$string['feedback'] = 'Feedback';
$string['viewdetails'] = 'View details';
$string['pendingevaluation'] = 'Pending evaluation...';
$string['allsubmissions'] = 'All submissions';
$string['viewallsubmissions'] = 'View all submissions';
$string['nosubmission'] = 'No submission yet';

// Submission
$string['submissionsaved'] = 'Your answer has been submitted and will be evaluated automatically';
$string['submissionfailed'] = 'Failed to submit answer';
$string['answerrequired'] = 'Answer is required';
$string['answertoolong'] = 'The answer is too long (maximum {$a} characters).';

// Evaluation
$string['score'] = 'Score';
$string['aifeedback'] = 'AI Feedback';
$string['aianalysis'] = 'Detailed analysis';
$string['evaluating'] = 'Evaluating with AI...';
$string['evaluationfailed'] = 'Automatic evaluation failed';

// Settings
$string['openaiapikey'] = 'OpenAI API Key';
$string['openaiapikey_desc'] = 'Enter your OpenAI API key for automatic evaluation. Get one at https://platform.openai.com/api-keys';
$string['openaimodel'] = 'OpenAI Model';
$string['openaimodel_desc'] = 'Select the OpenAI model to use for evaluation (default: gpt-4o-mini)';
$string['demomode'] = 'Demo Mode';
$string['demomode_desc'] = 'Enable demo mode to test without OpenAI API (uses simulated evaluation)';
$string['maxresponsetime'] = 'Max Response Time';
$string['maxresponsetime_desc'] = 'Maximum time in seconds to wait for OpenAI API response (default: 30)';
$string['noapikey'] = 'OpenAI API key not configured. Please configure it in plugin settings or enable demo mode.';

// Events
$string['eventsubmissioncreated'] = 'Submission created';
$string['eventsubmissiongraded'] = 'Submission graded';
$string['eventcoursemoduleviewed'] = 'Course module viewed';

// Submissions page
$string['student'] = 'Student';
$string['attempt'] = 'Attempt';
$string['status'] = 'Status';
$string['actions'] = 'Actions';
$string['evaluated'] = 'Evaluated';
$string['pending'] = 'Pending';
$string['nosubmissions'] = 'No submissions yet';
$string['statistics'] = 'Statistics';
$string['totalsubmissions'] = 'Total submissions';
$string['averagescore'] = 'Average score';
$string['backtosubmissions'] = 'Back to submissions';

// Submission detail
$string['submissiondetails'] = 'Submission details';
$string['submissioninfo'] = 'Submission information';
$string['youranswer'] = 'Your answer';
$string['evaluation'] = 'Evaluation';
$string['reevaluate'] = 'Re-evaluate';
$string['reevaluate_help'] = 'This will re-evaluate the submission with AI. The previous grade will be replaced.';

// Index page
$string['submissions'] = 'Submissions';

// Notifications (mejora #3)
$string['notif_graded_subject']  = 'Your assignment "{$a}" has been graded';
$string['notif_graded_body']     = "Your assignment \"{$a->assignment}\" has been graded.\n\nScore: {$a->score}%\n\nFeedback: {$a->feedback}";
$string['notif_graded_small']    = 'Grade received: {$a}%';

// Character counter (mejora #6)
$string['characters']            = 'characters';

// Privacy
$string['privacy:metadata:aiassignment_submissions'] = 'Information about user submissions for AI assignments';
$string['privacy:metadata:aiassignment_submissions:userid'] = 'The ID of the user who made the submission';
$string['privacy:metadata:aiassignment_submissions:answer'] = 'The answer submitted by the user';
$string['privacy:metadata:aiassignment_submissions:status'] = 'The status of the submission (pending or evaluated)';
$string['privacy:metadata:aiassignment_submissions:score'] = 'The score received for the submission';
$string['privacy:metadata:aiassignment_submissions:feedback'] = 'Feedback provided for the submission';
$string['privacy:metadata:aiassignment_submissions:attempt'] = 'The attempt number';
$string['privacy:metadata:aiassignment_submissions:timecreated'] = 'The time when the submission was created';
$string['privacy:metadata:aiassignment_submissions:timemodified'] = 'The time when the submission was last modified';
$string['privacy:metadata:aiassignment_evaluations'] = 'Information about AI evaluations of submissions';
$string['privacy:metadata:aiassignment_evaluations:similarity_score'] = 'The similarity score calculated by AI';
$string['privacy:metadata:aiassignment_evaluations:ai_feedback'] = 'Feedback generated by AI';
$string['privacy:metadata:aiassignment_evaluations:ai_analysis'] = 'Detailed analysis generated by AI';
$string['privacy:metadata:aiassignment_evaluations:timecreated'] = 'The time when the evaluation was created';
$string['privacy:metadata:core_grades'] = 'AI Assignment stores grades in the gradebook';
$string['privacy:metadata:openai'] = 'AI Assignment sends data to OpenAI for evaluation';
$string['privacy:metadata:openai:answer'] = 'The student answer sent to OpenAI for evaluation';
$string['privacy:metadata:openai:solution'] = 'The teacher solution sent to OpenAI for comparison';

// Dashboard
$string['dashboard'] = 'Dashboard';
$string['activestudents'] = 'Active students';
$string['pendingevaluations'] = 'Pending evaluations';
$string['recentsubmissions'] = 'Recent submissions';
$string['submittedon'] = 'Submitted on';
$string['grade'] = 'Grade';
$string['view'] = 'View';
$string['gradedistribution'] = 'Grade distribution';
$string['topperformers'] = 'Top performers';
$string['nodataavailable'] = 'No data available yet';
$string['averagegrade'] = 'Average grade';
$string['totalassignments'] = 'Total assignments';
$string['assignmentsoverview'] = 'Assignments overview';
$string['assignment'] = 'Assignment';
$string['viewsubmissions'] = 'View submissions';
$string['noassignments'] = 'No AI Assignments in this course yet';


// Plagiarism detection
$string['plagiarismreport'] = 'Plagiarism Report';
$string['selectproblemforplagiarism'] = 'Select a problem to analyze for plagiarism:';
$string['analyzeplagiarism'] = 'Analyze Plagiarism';
$string['plagiarismanalysisinfo'] = 'This analysis uses AI to compare all submissions and detect potential plagiarism. It analyzes semantic, structural, and logical similarities.';
$string['analyzingplagiarism'] = 'Analyzing submissions for plagiarism... This may take a few moments.';
$string['summary'] = 'Summary';
$string['totalcomparisons'] = 'Total comparisons';
$string['suspiciouspairs'] = 'Suspicious pairs';
$string['highestsimilarity'] = 'Highest similarity';
$string['suspicioususers'] = 'Suspicious Users';
$string['suspiciousmatches'] = 'Suspicious Matches';
$string['matchedwith'] = 'Matched With';
$string['detailedcomparisons'] = 'Detailed Comparisons';
$string['similarity'] = 'Similarity';
$string['verdict'] = 'Verdict';
$string['startanalysis'] = 'Start Plagiarism Analysis';
$string['plagiarismdetectionerror'] = 'Plagiarism detection error';
$string['plagiarismdetectionfailed'] = 'Plagiarism detection failed';
$string['noproblems'] = 'No problems available';

// ── Improvements v2.4.0 ───────────────────────────────────────────────────

// Bulk actions
$string['bulk_reevaluate']       = 'Re-evaluate selected';
$string['bulk_flag']             = 'Flag as plagiarism';
$string['bulk_unflag']           = 'Unflag plagiarism';
$string['bulk_select_all']       = 'Select all';
$string['bulk_no_selection']     = 'No submissions selected';
$string['bulk_confirm_reevaluate'] = 'Re-evaluate {$a} submission(s)? Previous grades will be replaced.';
$string['bulk_confirm_flag']     = 'Flag {$a} submission(s) as plagiarism?';

// Submission versioning
$string['version_history']       = 'Version history';
$string['version_reason']        = 'Change reason';
$string['version_resubmit']     = 'Resubmission';
$string['version_reevaluate']   = 'Re-evaluation';
$string['version_manual']       = 'Manual grading';
$string['no_versions']          = 'No previous versions';

// Audit log
$string['audit_log']            = 'Audit log';
$string['audit_manual_grade']   = 'Manual grade';
$string['audit_reevaluate']     = 'Re-evaluation';
$string['audit_plagiarism_confirm'] = 'Plagiarism confirmed';
$string['audit_plagiarism_dismiss'] = 'Plagiarism dismissed';
$string['audit_resubmit']      = 'Resubmission requested';

// OpenAI rate limiting
$string['openai_rate_limit']    = 'API calls limit per hour';
$string['openai_rate_limit_desc'] = 'Maximum OpenAI API calls per hour to prevent quota exhaustion (default: 100)';
$string['openai_rate_exceeded'] = 'API call limit reached. Please try again later.';

// Async plagiarism analysis
$string['plagiarism_async_queued'] = 'Plagiarism analysis queued. You will be notified when complete.';
$string['plagiarism_async_running'] = 'Analysis in progress...';

// Accessibility
$string['aria_score_high']      = 'High score';
$string['aria_score_medium']    = 'Medium score';
$string['aria_score_low']       = 'Low score';
$string['aria_plagiarism_high'] = 'High plagiarism risk';
$string['aria_plagiarism_medium'] = 'Medium plagiarism risk';
$string['aria_plagiarism_low']  = 'Low plagiarism risk';
$string['aria_dark_mode']       = 'Toggle dark/light theme';
$string['aria_filter_status']   = 'Filter submissions by status';
$string['aria_search_students'] = 'Search by student name';
$string['aria_sort_column']     = 'Sort by this column';

// Data cleanup
$string['task_cleanup']         = 'Clean up old data';
$string['task_analyze_plagiarism'] = 'Background plagiarism analysis';

// ── Language enforcement (v2.5) ───────────────────────────────────────────

// Form
$string['required_language']      = 'Required programming language';
$string['required_language_help'] = 'Restrict submissions to a specific language. Students who submit in a different language will see an error. Leave empty to accept any language.';
$string['lang_any']               = '— Any language —';

// Validation error shown to the student
$string['wrong_language']         = '❌ This assignment requires {$a->required}. Your code appears to be written in {$a->detected}. Please rewrite your solution in {$a->required}.';
$string['wrong_language_unknown'] = '❌ This assignment requires {$a->required}. Please make sure your solution is written in {$a->required}.';

// Shown in the assignment view (student hint)
$string['language_required_hint'] = '🔤 Required language: <strong>{$a}</strong>';
$string['language_any_hint']      = '🔤 Any programming language accepted';

// ── Deadline (v2.5.1) ─────────────────────────────────────────────────────
$string['duedate']                = 'Due date';
$string['duedate_help']           = 'Date and time after which no more submissions are accepted. Leave empty for no deadline.';
$string['timeopen']               = 'Available from';
$string['timeopen_help']          = 'Date and time from which students can view and submit the assignment. Leave empty to make it available immediately.';
$string['duedatebeforetimeopen']  = 'The due date must be after the open date.';
$string['assignmentclosed']       = '🔒 This assignment closed on {$a}. No more submissions are accepted.';
$string['assignmentnotopen']      = '⏳ This assignment will be available from {$a}.';
$string['duedatesoon']            = '⚠️ Due date: {$a}';
$string['duedatepassed']          = '🔴 Due date passed: {$a}';
$string['timeremaining']          = '⏱️ Time remaining: {$a}';
$string['detected_language']      = 'Detected language: {$a}';

// ── Availability and deadline (v2.5.1) ───────────────────────────────────
$string['timeopen']              = 'Open date';
$string['timeopen_help']         = 'Date and time from which students can submit answers. Leave empty for immediate availability.';
$string['duedate']               = 'Due date';
$string['duedate_help']          = 'Deadline for submitting answers. After this date no new submissions will be accepted. Leave empty for no limit.';
$string['pastduedate']           = '⛔ The submission deadline has passed. No more submissions are accepted.';
$string['assignmentnotopen']     = '🔒 This assignment is not yet available.';
$string['duedatesoon']           = '⚠️ Due date is soon: {$a}';
$string['submissiondetectedlang']= 'Detected language';
