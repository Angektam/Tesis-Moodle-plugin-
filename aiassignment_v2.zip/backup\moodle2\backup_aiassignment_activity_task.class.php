<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/aiassignment/backup/moodle2/backup_aiassignment_stepslib.php');

/**
 * Tarea de backup para mod_aiassignment
 */
class backup_aiassignment_activity_task extends backup_activity_task {

    /**
     * Define configuraciones particulares para esta actividad
     */
    protected function define_my_settings() {
        // No hay configuraciones particulares para esta actividad
    }

    /**
     * Define pasos particulares para esta actividad
     */
    protected function define_my_steps() {
        $this->add_step(new backup_aiassignment_activity_structure_step('aiassignment_structure', 'aiassignment.xml'));
    }

    /**
     * Codifica URLs de contenido en la actividad
     *
     * @param string $content
     * @return string
     */
    static public function encode_content_links($content) {
        global $CFG;

        $base = preg_quote($CFG->wwwroot, '/');

        // Link al índice de AI Assignment
        $search = "/(" . $base . "\/mod\/aiassignment\/index.php\?id\=)([0-9]+)/";
        $content = preg_replace($search, '$@AIASSIGNMENTINDEX*$2@$', $content);

        // Link a la vista de AI Assignment
        $search = "/(" . $base . "\/mod\/aiassignment\/view.php\?id\=)([0-9]+)/";
        $content = preg_replace($search, '$@AIASSIGNMENTVIEWBYID*$2@$', $content);

        return $content;
    }
}
