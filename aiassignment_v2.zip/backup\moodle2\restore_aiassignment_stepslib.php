<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Define los pasos de restore para mod_aiassignment
 */
class restore_aiassignment_activity_structure_step extends restore_activity_structure_step {

    /**
     * Define la estructura del restore
     */
    protected function define_structure() {

        $paths = array();
        $userinfo = $this->get_setting_value('userinfo');

        // Definir rutas
        $paths[] = new restore_path_element('aiassignment', '/activity/aiassignment');
        
        if ($userinfo) {
            $paths[] = new restore_path_element('aiassignment_submission', 
                '/activity/aiassignment/submissions/submission');
            $paths[] = new restore_path_element('aiassignment_evaluation', 
                '/activity/aiassignment/submissions/submission/evaluations/evaluation');
        }

        return $this->prepare_activity_structure($paths);
    }

    /**
     * Procesa el elemento aiassignment
     */
    protected function process_aiassignment($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;
        $data->course = $this->get_courseid();

        $data->timecreated = $this->apply_date_offset($data->timecreated);
        $data->timemodified = $this->apply_date_offset($data->timemodified);

        // Insertar el registro
        $newitemid = $DB->insert_record('aiassignment', $data);
        
        // Guardar el mapeo
        $this->apply_activity_instance($newitemid);
    }

    /**
     * Procesa el elemento submission
     */
    protected function process_aiassignment_submission($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->assignment = $this->get_new_parentid('aiassignment');
        $data->userid = $this->get_mappingid('user', $data->userid);
        $data->timecreated = $this->apply_date_offset($data->timecreated);
        $data->timemodified = $this->apply_date_offset($data->timemodified);

        $newitemid = $DB->insert_record('aiassignment_submissions', $data);
        $this->set_mapping('aiassignment_submission', $oldid, $newitemid);
    }

    /**
     * Procesa el elemento evaluation
     */
    protected function process_aiassignment_evaluation($data) {
        global $DB;

        $data = (object)$data;
        $oldid = $data->id;

        $data->submission = $this->get_new_parentid('aiassignment_submission');
        $data->timecreated = $this->apply_date_offset($data->timecreated);

        $newitemid = $DB->insert_record('aiassignment_evaluations', $data);
        // No necesitamos mapeo para evaluations
    }

    /**
     * Acciones después del restore
     */
    protected function after_execute() {
        // Agregar archivos relacionados
        $this->add_related_files('mod_aiassignment', 'intro', null);
    }
}
