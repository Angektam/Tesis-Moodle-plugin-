<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

require_once($CFG->dirroot . '/mod/aiassignment/backup/moodle2/restore_aiassignment_stepslib.php');

/**
 * Tarea de restore para mod_aiassignment
 */
class restore_aiassignment_activity_task extends restore_activity_task {

    /**
     * Define configuraciones particulares para esta actividad
     */
    protected function define_my_settings() {
        // No hay configuraciones particulares para esta actividad
    }

    /**
     * Define pasos particulares para esta actividad
     */
    protected function define_my_steps() {
        $this->add_step(new restore_aiassignment_activity_structure_step('aiassignment_structure', 'aiassignment.xml'));
    }

    /**
     * Decodifica URLs de contenido en la actividad
     *
     * @param string $content
     * @return string
     */
    static public function decode_content_links($content) {
        global $CFG;

        $base = preg_quote($CFG->wwwroot, '/');

        // Link al índice de AI Assignment
        $search = '/\$@AIASSIGNMENTINDEX\*([0-9]+)@\$/';
        $content = preg_replace($search, $CFG->wwwroot.'/mod/aiassignment/index.php?id=$1', $content);

        // Link a la vista de AI Assignment
        $search = '/\$@AIASSIGNMENTVIEWBYID\*([0-9]+)@\$/';
        $content = preg_replace($search, $CFG->wwwroot.'/mod/aiassignment/view.php?id=$1', $content);

        return $content;
    }
}
