<?php
// This file is part of Moodle - http://moodle.org/

defined('MOODLE_INTERNAL') || die();

/**
 * Define los pasos de backup para mod_aiassignment
 */
class backup_aiassignment_activity_structure_step extends backup_activity_structure_step {

    /**
     * Define la estructura del backup
     */
    protected function define_structure() {

        // Define cada elemento que será respaldado
        $userinfo = $this->get_setting_value('userinfo');

        // Definir el elemento raíz
        $aiassignment = new backup_nested_element('aiassignment', array('id'), array(
            'course', 'name', 'intro', 'introformat', 'type', 'solution',
            'documentation', 'test_cases', 'grade', 'maxattempts',
            'timecreated', 'timemodified'
        ));

        // Definir elementos de envíos (solo si se incluye información de usuario)
        $submissions = new backup_nested_element('submissions');
        $submission = new backup_nested_element('submission', array('id'), array(
            'userid', 'answer', 'status', 'score', 'feedback', 'attempt',
            'timecreated', 'timemodified'
        ));

        // Definir elementos de evaluaciones
        $evaluations = new backup_nested_element('evaluations');
        $evaluation = new backup_nested_element('evaluation', array('id'), array(
            'similarity_score', 'ai_feedback', 'ai_analysis', 'timecreated'
        ));

        // Construir el árbol
        $aiassignment->add_child($submissions);
        $submissions->add_child($submission);
        $submission->add_child($evaluations);
        $evaluations->add_child($evaluation);

        // Definir fuentes de datos
        $aiassignment->set_source_table('aiassignment', array('id' => backup::VAR_ACTIVITYID));

        // Solo incluir envíos si se solicita información de usuario
        if ($userinfo) {
            $submission->set_source_table('aiassignment_submissions', 
                array('assignment' => backup::VAR_PARENTID));
            
            $evaluation->set_source_table('aiassignment_evaluations', 
                array('submission' => backup::VAR_PARENTID));
        }

        // Definir anotaciones de ID
        $submission->annotate_ids('user', 'userid');

        // Definir anotaciones de archivos
        $aiassignment->annotate_files('mod_aiassignment', 'intro', null);

        return $this->prepare_activity_structure($aiassignment);
    }
}
